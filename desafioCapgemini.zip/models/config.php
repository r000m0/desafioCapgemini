<?php 

	#rotas
	
	$project_name = "/desafioCapgemini/"; #Nome do projeto (nome da pasta raiz do programa)
	$project_index = "http://".$_SERVER['SERVER_NAME'].$project_name; #Url do caminho do servidor na rede
	$project_path = $_SERVER['DOCUMENT_ROOT'].$project_name; #Url do caminho do servidor na raiz

	#rotas globais
	$GLOBALS['project_index'] = $project_index; 
	$GLOBALS['project_path'] = $project_path;

 ?>