<?php 
	
	ini_set('display_errors', 1);
	//ini_set('display_startup_errors', 1);
	error_reporting(E_ALL | E_WARNING);

	include_once 'models/config.php';
	include_once $project_path.'views/template.html';
	include_once $project_path.'controllers/options.php';

	

?>