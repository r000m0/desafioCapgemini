	<form action="calculadora.php" method="POST">

		<label>Investimento por dia</label>
		<input type="number" class="form-control" name="investment" placeholder="Valor em R$">
		<input type="submit" value="Calcular">

	</form>

<?php

	$investment = $_POST['investment'];
	$view = $investment * 30; 
	$click = ($view/100)*12; //Cliques correspondem a 12% das visualizações
	$share = ($click/100)*15; //Compartilhamentos correspondem a 15% dos cliques
	$view = $view+($share*40); //Incluindo as visualizações oriundas dos compartilhamentos

	if ($investment) {
		
		echo "
			<br>
			Valor investido: R$ ",$investment,"<br>
			Visualizações esperadas: ",$view,"<br>
			Cliques esperados: ",$click,"<br>
			Compartilhamentos esperados: ",$share,"<br>"
			;
}


?>
