<?php 

	if (!isset($_GET['option'])){
		return false;
	} else {
		switch ($_GET['option']) {
			

			case 'new':
				include_once 'views/new.html';
			break;

			case 'manager':
				include_once 'views/manager.html';
			break;
						
		}
	}
	


?>