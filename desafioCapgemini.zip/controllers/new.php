<?php 
	
	include_once dirname(__DIR__)."/models/config.php";
/*	include_once $project_path."/controllers/options.php";*/
	$data = $_POST;


	$data = implode(" - ",$data);
	$archive = fopen("cadastroClientes.txt","a+");
	fwrite($archive, "{$data}\n");
	fclose($archive);

	header("location: $project_index?option=new");

?>