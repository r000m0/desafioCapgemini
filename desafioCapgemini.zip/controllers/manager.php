<?php


	
	$archive = file("controllers/cadastroClientes.txt");

	foreach ($archive as $k => $v) {
		$data = explode(" - ", $v);
		$archive[$k] = $data;
	}

	foreach ($archive as $k) {
		echo "<tr>";
		foreach ($k as $w) {
			echo "<td>",$w,"</td>";
		}
		echo "</tr>";
		
	}

?>

